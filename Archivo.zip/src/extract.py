import pandas as pd
import os

def extract_data(file_path): #se extrae los datos desde un archio Excel local (SIVIGILA)

    print(f"Iniciando extracción desde: {file_path}")
    try:
        
        df = pd.read_excel(file_path, engine='openpyxl')# Se utiliza el motor openpyxl para archivos .xlsx
        print(f"Extracción exitosa. Filas: {df.shape[0]}, Columnas: {df.shape[1]}")
        return df
    except Exception as e:
        print(f"Error en la extracción: {e}")
        return None #por si falla