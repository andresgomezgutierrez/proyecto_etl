import os
from src.extract import extract_data
from src.transform import transform_data
from src.load import load_data

def run_pipeline():
    print("INICIANDO PIPELINE ETL: SIVIGILA (Tuberculosis)")
    
    #Rutas de los archivos
    INPUT_FILE = os.path.join('data', 'raw', 'BD-813.xlsx')
    OUTPUT_FILE = os.path.join('data', 'processed', 'tuberculosis_clean_tolima.csv')
    
    #Extracción
    raw_data = extract_data(INPUT_FILE)
    
    if raw_data is not None:
        #Transformación
        transformed_data = transform_data(raw_data)
        
        #Carga
        load_data(transformed_data, OUTPUT_FILE)
        
        print("PIPELINE ETL FINALIZADO CON ÉXITO")
    else:
        print("El pipeline se detuvo debido a un error en la extracción.")

if __name__ == "__main__":
    run_pipeline()