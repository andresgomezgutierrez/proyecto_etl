import pandas as pd

def transform_data(df): #Limpia, anonimiza y transforma los datos de SIVIGILA (ejemplo Tuberculosis).
    print("Iniciando fase de transformación...")
    
    df_clean = df.copy() #Hace una copia de seguridad
    
    #Anonimización de datos sensibles (PII - Personal Identifiable Information)
    columnas_sensibles = ['pri_nom_', 'seg_nom_', 'pri_ape_', 'seg_ape_', 'num_ide_', 'dir_res_', 'telefono_']
    columnas_a_eliminar = [col for col in columnas_sensibles if col in df_clean.columns]
    df_clean = df_clean.drop(columns=columnas_a_eliminar)
    
    #Estandarización de Fechas (Fecha de notificación, inicio de síntomas, etc.)
    fechas_cols = ['fec_not', 'fec_con_', 'ini_sin_']
    for col in fechas_cols:
        if col in df_clean.columns:
            # las bases (ejemplo tuberculosis) usa formato DD/MM/YYYY habitualmente
            df_clean[col] = pd.to_datetime(df_clean[col], format='%d/%m/%Y', errors='coerce')
    
    #Filtro geográfico (Asegurando que sea departamento del Tolima cod_dpto_o == 73)
    if 'cod_dpto_o' in df_clean.columns:
        df_clean = df_clean[df_clean['cod_dpto_o'] == 73]
    
    #se da manejo de valores nulos en variables clave para epidemiología
    if 'edad_' in df_clean.columns:
        df_clean['edad_'] = df_clean['edad_'].fillna(df_clean['edad_'].median())
    
    if 'sexo_' in df_clean.columns:
        df_clean['sexo_'] = df_clean['sexo_'].fillna('Desconocido')
        
    #Normalización de nombres de columnas (minúsculas y sin espacios)
    df_clean.columns = df_clean.columns.str.lower().str.strip()
    
    print(f"Transformación completada. Filas resultantes: {df_clean.shape[0]}, Columnas: {df_clean.shape[1]}")
    return df_clean