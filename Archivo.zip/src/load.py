import os

def load_data(df, output_path): #Carga los datos transformados a un directorio local.

    print(f"Iniciando carga de datos en: {output_path}")
    try:
        #Asegurando de que el directorio exista
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        
        #Guardar el CSV limpio
        df.to_csv(output_path, index=False, encoding='utf-8')
        print("Carga de datos exitosa.")
    except Exception as e:
        print(f"Error durante la carga: {e}")